package com.inetpsa.trn.infrastructure.jpa.hibernate;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.trn.domain.model.aggregate.Department;
import com.inetpsa.trn.domain.repository.DepartmentRepository;

public class DepartmentJpaRepository extends BaseJpaRepository<Department, Integer> implements DepartmentRepository {

	
	@Override
	public List<Department> all() {
		CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		
		CriteriaQuery<Department> cquery=cb.createQuery(Department.class);
		cquery.from(getAggregateRootClass());
		
		TypedQuery<Department> tquery=getEntityManager().createQuery(cquery);
		
		return tquery.getResultList();
	}

}
