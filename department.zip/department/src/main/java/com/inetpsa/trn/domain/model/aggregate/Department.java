package com.inetpsa.trn.domain.model.aggregate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.seedstack.business.domain.BaseAggregateRoot;

//Base Aggregate Root
@Entity
public class Department extends BaseAggregateRoot<Integer> 
{
	@Id
	@Column(name="id")
	Integer id;
	
	@Column(name="name")
	String name;
	
	@OneToOne
	Department manager;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
