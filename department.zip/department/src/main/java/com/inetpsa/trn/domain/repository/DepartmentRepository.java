package com.inetpsa.trn.domain.repository;

import java.util.List;

import org.seedstack.business.domain.Repository;

import com.inetpsa.trn.domain.model.aggregate.Department;

public interface DepartmentRepository extends Repository<Department, Integer> {

	public List<Department> all();
}
