package com.inetpsa.trn.domain.model.aggregate;

import javax.persistence.EmbeddedId;
import javax.persistence.Id;

import org.seedstack.business.domain.BaseEntity;

public class EmployeeProject extends BaseEntity<EmployeeProjectId>{
	
	@Id
	@EmbeddedId
	EmployeeProjectId pk;

	public EmployeeProjectId getId() {
		return pk;
	}

	public void setId(EmployeeProjectId id) {
		this.pk = id;
	}
}
