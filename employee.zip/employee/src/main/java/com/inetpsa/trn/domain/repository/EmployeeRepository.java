package com.inetpsa.trn.domain.repository;

import java.util.List;

import org.seedstack.business.domain.Repository;

import com.inetpsa.trn.domain.model.aggregate.Employee;

public interface EmployeeRepository extends Repository<Employee, Integer> {

	public List<Employee> all();

	public List<Employee> byProject(Integer projectId);

}
