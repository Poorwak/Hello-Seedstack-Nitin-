package com.inetpsa.trn.domain.model.aggregate;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.OneToOne;

import org.seedstack.business.domain.BaseValueObject;

@Embeddable
public class EmployeeProjectId extends BaseValueObject{

	private static final long serialVersionUID = 1L;
	
	@OneToOne
	private Employee employee;
	
	@Column(name="project_id")
	Integer projectId;

	
	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}
}
