package com.inetpsa.trn.infrastructure.jpa.hibernate;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.seedstack.jpa.BaseJpaRepository;

import com.inetpsa.trn.domain.model.aggregate.Employee;
import com.inetpsa.trn.domain.repository.EmployeeRepository;

public class EmployeeJpaRepository extends BaseJpaRepository<Employee, Integer> implements EmployeeRepository 	{

	@Override
	public List<Employee> all() {
		//get criteria builder
		CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		
		//construct criteria query using criteria builder
		CriteriaQuery<Employee> cquery=cb.createQuery(Employee.class);
		cquery.from(getAggregateRootClass());
		
		//create typed query from criteria query
		TypedQuery<Employee> tquery=getEntityManager().createQuery(cquery);
		
		//fire the query
		return tquery.getResultList();
		
	}

	@Override
	public List<Employee> byProject(Integer projectId) {
		// TODO Auto-generated method stub
		return null;
	}	

	

}
